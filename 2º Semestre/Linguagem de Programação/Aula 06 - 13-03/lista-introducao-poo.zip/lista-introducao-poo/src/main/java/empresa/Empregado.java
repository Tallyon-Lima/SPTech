package empresa;

public class Empregado {
    String nome;
    String cargo;
    Double salario;
    Integer anosTrabalhados;
    String promocao;
    String novoCargo;

    Double reajustarSalario(Double porcentagem ){
       return salario+= salario * porcentagem;
    }

    void atribuirDados(){
        nome = "João";
        salario = 5400.00;
        cargo = "Analista de Sistemas";
    }

    void imprimirDados(){
        System.out.println("""
                O funcionario %s de cargo %s agora recebe %.2f como salário""".formatted(nome, cargo, salario));
    }

    void verificarPromocao(){
        if (promocao.equals("Sim")){
              System.out.println((" O funcionario %s de antigo cargo %s que " +
               "agora recebe %.2f como salário, foi promovido para " +
                 "%s pois está a %d anos na empresa").formatted(nome, cargo
                    , salario, novoCargo,anosTrabalhados));
    }else {
            System.out.println("O funcionario %s teve o ajuste no salário," +
                    " porém, ele não foi promovido pois está pouco na empresa".formatted(
                            nome));
        }

    }


}
