package confeitaria;

public class App {
    public static void main(String[] args) {
        Bolo tipoBolo01 = new Bolo();
        Bolo tipoBolo02 = new Bolo();
        Bolo tipoBolo03 = new Bolo();


        tipoBolo01.sabor = "Chocolate";
        tipoBolo01.valor = 10.50;
        tipoBolo01.qtdVendida = 6;

        tipoBolo02.sabor = "Morango";
        tipoBolo02.valor = 12.70;
        tipoBolo02.qtdVendida = 8;

        tipoBolo03.sabor = "Cenoura";
        tipoBolo03.valor = 11.30;
        tipoBolo03.qtdVendida = 0;

        tipoBolo01.comprarBolo(1);
        tipoBolo02.comprarBolo(23);
        tipoBolo03.comprarBolo(40);

        tipoBolo01.comprarBolo(1);
        tipoBolo02.comprarBolo(9);
        tipoBolo03.comprarBolo(3);

        tipoBolo01.comprarBolo(1);
        tipoBolo02.comprarBolo(2);
        tipoBolo03.comprarBolo(32);

        tipoBolo01.comprarBolo(1);
        tipoBolo02.comprarBolo(23);
        tipoBolo03.comprarBolo(4);

        tipoBolo01.comprarBolo(1);
        tipoBolo02.comprarBolo(6);
        tipoBolo03.comprarBolo(8);

        tipoBolo01.exibirRelatorio();
        tipoBolo02.exibirRelatorio();
        tipoBolo03.exibirRelatorio();



    }
}
