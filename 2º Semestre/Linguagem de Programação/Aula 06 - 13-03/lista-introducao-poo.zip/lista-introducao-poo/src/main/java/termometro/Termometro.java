package termometro;

public class Termometro {
    Double temperaturaAtual;
    Double temperaturaMax;
    Double temperaturaMin;

    void aumentaTemperatura(Double valor){
        temperaturaAtual += valor;

        if (temperaturaMax <= temperaturaAtual){
            temperaturaAtual = temperaturaMax;
        }
        System.out.println("Temperatura atual:" + temperaturaAtual);
    }

    void diminuiTemperatura(Double valor){
        temperaturaAtual -= valor;

        if (temperaturaAtual <= temperaturaMin){
            temperaturaAtual = temperaturaMin;
        }
        System.out.println("Temperatura atual:" + temperaturaAtual);
    }

    void exibeFahreinheit(){
        Double fahrenheit = (temperaturaAtual * 9/5) + 32;

        System.out.println("A atual na escala fahrenheit é: "+ fahrenheit);
    }



}
