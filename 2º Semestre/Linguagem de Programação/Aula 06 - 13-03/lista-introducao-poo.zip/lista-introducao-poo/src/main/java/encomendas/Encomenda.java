package encomendas;

public class Encomenda {
    String tamanho;
    String enderecoRemetente;
    String enderecoDestinatario;
    Double distancia;
    Double valorEncomenda;
    Double frete = 0.0 ;


    void calcularFrete(){
        if (tamanho.equals("P")){
            frete += valorEncomenda * 0.01;
        }else if (tamanho.equals("M")){
            frete += valorEncomenda * 0.03;
        }else{
            frete += valorEncomenda * 0.05;
        }

        if (distancia <= 50){
            frete += 3;
        } else if (distancia <= 200) {
            frete += 5;
        }else {
            frete += 7;
        }
    }

    void emitirEtiqueta(){
        System.out.println("""
                
                ***** ETIQUETA PARA ENVIO *****
                Endereço do remetente: %s
                Endereço do destinatário: %s
                Tamanho: %s
                --------------------------------------------------
                Valor encomenda: R$ %.2f
                Valor frete: R$ %.2f
                --------------------------------------------------
                Valor total: R$ %.2f
                """.formatted(enderecoRemetente, enderecoDestinatario, tamanho,
                valorEncomenda, frete, (valorEncomenda + frete)));
    }



}
