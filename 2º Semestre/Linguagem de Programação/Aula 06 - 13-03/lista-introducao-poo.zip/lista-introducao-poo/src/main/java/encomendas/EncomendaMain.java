package encomendas;

import java.util.Scanner;

public class EncomendaMain {
    public static void main(String[] args) {
        Encomenda pedido01 = new Encomenda();
        Encomenda pedido02 = new Encomenda();

        pedido01.tamanho = "G";
        pedido01.enderecoDestinatario = "Av Dr. Pedro, 255";
        pedido01.enderecoRemetente = "Rua Santos da Glória, 18)";
        pedido01.distancia = 42.2;
        pedido01.valorEncomenda = 87.50;


        pedido02.tamanho = "P";
        pedido02.enderecoDestinatario = "Av D. João, 1950";
        pedido02.enderecoRemetente = "Av Dr. Pedro, 18)";
        pedido02.distancia = 201.0;
        pedido02.valorEncomenda = 62.25;


        pedido01.calcularFrete();
        pedido02.calcularFrete();
        pedido01.emitirEtiqueta();
        pedido02.emitirEtiqueta();

    }
}
